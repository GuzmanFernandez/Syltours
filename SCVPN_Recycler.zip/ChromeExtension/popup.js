// popup.js
document.getElementById("getUrlBtn").addEventListener("click", function() {
  chrome.runtime.sendMessage({ type: "getLastUrl" }, function(response) {
    document.getElementById("lastUrlDisplay").innerText = "Last URL: " + response;
  });
});
