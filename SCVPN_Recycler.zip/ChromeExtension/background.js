chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "sendUrl") {
    // Get the current tab's URL
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      const currentUrl = tabs[0].url;
      console.log('Current tab URL:', currentUrl);

      // Sanitize the URL by removing unwanted leading characters (if any)
      const sanitizedUrl = sanitizeUrl(currentUrl);
      
      // Send the sanitized URL to the native host app using sendNativeMessage
      const nativeMessage = { action: 'sendUrl', url: sanitizedUrl };
      
      console.log("Sending message to native host:", nativeMessage); // Log the message being sent

      chrome.runtime.sendNativeMessage('com.sabre.scvpn_recycler', nativeMessage, function(response) {
        if (chrome.runtime.lastError) {
          //console.error("Error sending message to native host:", chrome.runtime.lastError.message);
        } else {
          console.log('Response from native host:', response);
        }
      });
    });
  }
});

function sanitizeUrl(url) {
  // Define the unwanted leading character(s), such as a space or '#'
  const unwantedCharacter = "#"; // Replace this with the unwanted character

  if (url.startsWith(unwantedCharacter)) {
    url = url.slice(1); // Remove the first character
  }

  // Ensure the URL is properly encoded
  return encodeURI(url); // Optionally, encode the URL to handle special characters
}
