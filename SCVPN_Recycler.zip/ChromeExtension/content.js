// content.js

// Send message to background script to get current tab URL and pass it to native host
chrome.runtime.sendMessage({ action: 'sendUrl' }, function(response) {
  console.log('URL sent to native host');
});
